﻿#target photoshop;

app.bringToFront;

var str_palceHere;
var str_createFolder;
var str_remove;

if(app.locale == "zh_CN"){
    str_palceHere = '将‘Typer-package’文件夹放在这里';
    str_createFolder_pre = '无法找到并创建Generator文件夹，请手动创建';
    str_createFolder_end = '/Plug-ins/Generator 文件夹';
    str_remove = '请手动删除旧版本Typer';
}else{
    str_palceHere = 'Place ‘Typer-package’ folder here';
    str_createFolder_pre = 'Unable to find and create the Generator folder, please create';
    str_createFolder_end = '/Plug-ins/Generator folder manually';
    str_remove = 'Please delete the old Typer manually';
};

install();

function install(){
    
    var generatorFolder = Folder(app.path.fullName+'/Plug-ins/Generator/');
    var ocrTargetFolder = Folder(app.path.fullName+'/Plug-ins/Generator/Typer-package/');
    var tipFile = File(app.path.fullName+'/Plug-ins/Generator/' + str_palceHere)
    
    if(!generatorFolder.exists){
           if(!generatorFolder.create()){
                alert(str_createFolder_pre + app.path.fullName + str_createFolder_end);
                return;
               };
        };

        if(ocrTargetFolder.exists){
            if(!ocrTargetFolder.remove()){
                    alert(str_remove);
                    generatorFolder.execute();
                    return;
                };
        };

        tipFile.open('w');
        tipFile.close();

        (new File($.fileName)).parent.execute();
        
        generatorFolder.execute();

};

